#include <opencv2/opencv.hpp>  //头文件
#include <opencv2/xfeatures2d.hpp>
#include <opencv2/optflow/motempl.hpp>
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <stdio.h>
#include <math.h>
#include <algorithm>
#include <opencv2/imgproc/types_c.h>
using namespace cv;
using namespace std;


void camera_cal(vector<string> &FilesName, Size &board_size, Size &square_size, Mat &cameraMatrix, Mat &distCoeffs, vector<Mat> &rvecsMat, vector<Mat> &tvecsMat)
{
    ofstream fout("caliberation_result.txt");                        //保存标定结果的文件，若使用vs则在工作目录下，若使用xcode则在/Users/username/Library/Developer/Xcode/DerivedData下
    string FileName;                                                //校正后图像的保存路径
    string temp;
    cout << "Start corner detection!" << endl;
    int cnt = 0;                                            // 图像数量
    Size image_size;                                                // 图像的尺寸

    vector<Point2f> corner_points;                                   // 缓存每幅图像上检测到的角点
    vector<vector<Point2f>> corner_points_seq;                       // 保存检测到的所有角点
    if (FilesName.size() < 3){
        cout << "Calibrate failed, with less than three images!" << endl;
        return;
    }
    //获取图像宽高以及通道信息
    Mat imageSample = imread(FilesName[0]);
    image_size.width = imageSample.cols;
    image_size.height = imageSample.rows;
    cout << "image_size.width = " << image_size.width << endl;
    cout << "image_size.height = " << image_size.height << endl;
    cout << "imageInput.channels=" << imageSample.channels() << endl;
    
    for (int i = 0; i < FilesName.size(); i++)
    {
        cnt++;
        // 用于观察检验输出
        cout << "No." << cnt << " image starts!" << endl;
        Mat imageInput = imread(FilesName[i]);
        

        /* 提取角点 */
        bool ok = findChessboardCorners(imageInput, board_size, corner_points, CALIB_CB_ADAPTIVE_THRESH | CALIB_CB_NORMALIZE_IMAGE | CALIB_CB_FAST_CHECK | CALIB_CB_FILTER_QUADS);
        if (!ok)
        {
            cout << "Corner detect failed!" << endl; //角点检测失败
            imshow("Failed", imageInput);
            waitKey(0);
        }
        else
        {
            Mat image_gray;
            cvtColor(imageInput, image_gray, CV_RGB2GRAY);
            /* 亚像素精确化 */
            //find4QuadCornerSubpix(image_gray, corner_points, Size(11, 11)); //对粗提取的角点进行精确化
            cornerSubPix(image_gray, corner_points, Size(11, 11), Size(-1, -1), cv::TermCriteria(CV_TERMCRIT_ITER + CV_TERMCRIT_EPS, 30, 0.01));
            
            //！！！！！！！！！！！！！！！！！winsize(11,11)如何确定？

            corner_points_seq.push_back(corner_points);  //保存亚像素角点
                        
            drawChessboardCorners(image_gray, board_size, corner_points, true);
            imshow("Camera Calibration", image_gray);//显示图片
            waitKey(200);//暂停
           
            temp = to_string((i+1));
            FileName = "/Users/mars/Desktop/zju/stereo/Project_Stereo_left/left_findchesscorner/findchesscorner" + temp + ".jpg";//指定保存绘制角点后的图像的路径
            imwrite(FileName, image_gray);
            FileName.clear();

        }
    }
    cout << "Corner detect done!" << endl;


    /*棋盘三维信息*/
    vector<vector<Point3f>> object_points_seq;                     // 保存标定板上角点的三维坐标

    for (int t = 0; t < cnt; t++)
    {
        vector<Point3f> object_points;
        for (int i = 0; i < board_size.height; i++)
        {
            for (int j = 0; j < board_size.width; j++)
            {
                Point3f realPoint;
                /* 假设标定板放在世界坐标系中z=0的平面上 */
                realPoint.x = i * square_size.width;
                realPoint.y = j * square_size.height;
                realPoint.z = 0;
                object_points.push_back(realPoint);
            }
        }
        
        object_points_seq.push_back(object_points);
    }


    
    /* 运行标定函数 */
    double error1 = calibrateCamera(object_points_seq, corner_points_seq, image_size, cameraMatrix, distCoeffs, rvecsMat, tvecsMat, CALIB_FIX_K3);
    
    fout << "The average of re-projection error：" << error1 << " pixel" << endl << endl;
    cout << cameraMatrix << endl;
    cout << distCoeffs << endl;
    


    cout << "Start evaluating the result of calibration!" << endl;
    double total_err = 0.0;            // 所有图像的平均误差的总和
    double err = 0.0;                  // 每幅图像的平均误差
    vector<Point2f> corner_points_new;     // 保存重新计算得到的投影点

    for (int i = 0; i < cnt; i++)
    {

        projectPoints(object_points_seq[i], rvecsMat[i], tvecsMat[i], cameraMatrix, distCoeffs, corner_points_new);   //通过得到的摄像机内外参数，对角点的空间三维坐标进行重新投影计算

        err = norm(Mat(corner_points_seq[i]), Mat(corner_points_new), NORM_L2);//NORM_L2求欧式距离，每两个对应角点的距离的平方和相加再开方
        err /= object_points_seq[i].size();
        fout << "The average error of No." << i + 1 << " image：" << err << " pixel" << endl;
        total_err += err;
    }
    fout << "The average error of all images：" << total_err / cnt << " pixel" << endl << endl;


    //保存定标结果
    cout << "Start saving results!" << endl;
    Mat rotation_matrix = Mat(3, 3, CV_32FC1, Scalar::all(0)); /* 保存每幅图像的旋转矩阵 */
    fout << "The intrinsic matrix：" << endl;
    fout << cameraMatrix << endl << endl;
    fout << "The distortion coefficient：\n";
    fout << distCoeffs << endl << endl << endl;
    for (int i = 0; i < cnt; i++)
    {
        fout << "The rotation vector of No." << i + 1 << " image：" << endl;
        fout << rvecsMat[i] << endl;
        /* 将旋转向量转换为相对应的旋转矩阵 */
        Rodrigues(rvecsMat[i], rotation_matrix);
        fout << "The rotation matrix of No." << i + 1 << " image：" << endl;
        fout << rotation_matrix << endl;
        fout << "The translation matrix of No." << i + 1 << " image：" << endl;
        fout << tvecsMat[i] << endl << endl;
    }
    cout << "Results are saved!" << endl;
    fout << endl;
    cout << "Calibration done!" << endl;
}

void img_undistort(vector<string> &FilesName, Size &image_size, Mat &cameraMatrix, Mat &distCoeffs)
{
    if (FilesName.size() < 3){
        cout << "Undistort failed, with less than three images!" << endl;
        return;
    }

    cout << "Save undistorted images!" << endl;
    string imageFileName;                  //校正后图像的保存路径
    string temp;
    /*以下参数用于方法一*/
    double k1 = -0.2786674418588524, k2 = 0.06725182393050162, p1 = 0.001822677105300239, p2 = -0.0003437522547153352;
    double fx = 536.452715035752, fy = 536.4048645322116, cx = 342.3673157917998, cy = 235.5432530124777;



    for (int i = 0; i < FilesName.size(); i++)
    {
        
        //方法一：使用相机参数结合畸变方程矫正图片
        Mat imageSource = imread(FilesName[i],0);
        int rows = imageSource.rows, cols = imageSource.cols;
        Mat newimage = Mat(rows, cols, CV_8UC1);    // 图像是灰度图，CV_8UC1
        for (int v = 0; v < rows; v++) {
            for (int u = 0; u < cols; u++) {
                double u_distorted = 0, v_distorted = 0;
                
                /*将image_undistort的坐标通过内参转换到归一化坐标系下，此时得到的归一化坐标是对的
                将得到的归一化坐标系进行畸变处理
                将畸变处理后的坐标通过内参转换为图像坐标系下的坐标
                这样就相当于是在非畸变图像的图像坐标和畸变图像的图像坐标之间建立了一个对应关系
                相当于是非畸变图像坐标在畸变图像中找到了映射*/
                double x1, x2, y1, y2;
                x1 = (u - cx) / fx;
                y1 = (v - cy) / fy;
                double r2;
                r2 = pow(x1, 2) + pow(y1, 2);
                x2 = x1 * (1 + k1 * r2 + k2 * pow(r2, 2)) + 2 * p1 * x1 * y1 + p2 * (r2 + 2 * x1 * x1);
                y2 = y1 * (1 + k1 * r2 + k2 * pow(r2, 2)) + 2 * p2 * x1 * y1 + p1 * (r2 + 2 * y1 * y1);
                u_distorted = fx * x2 + cx;
                v_distorted = fy * y2 + cy;


                // 赋值 (最近邻插值)
                if (u_distorted >= 0 && v_distorted >= 0 && u_distorted < cols && v_distorted < rows) {
                    newimage.at<uchar>(v, u) = imageSource.at<uchar>((int)v_distorted, (int)u_distorted);
                }
                else {
                    newimage.at<uchar>(v, u) = 0;
                }
            }
        }

        //方法二：使用undistort函数实现
//        Mat imageSource = imread(FilesName[i]);
//
//        Mat newimage = imageSource.clone();
//        undistort(imageSource, newimage, cameraMatrix, distCoeffs);

        temp = to_string((i+1));
        imageFileName = "/Users/mars/Desktop/zju/stereo/Project_Stereo_left/left_undisort/方法二" + temp + ".jpg";//指定保存矫正后的图片的路径
        cout << "Undistort No." << i+1 << " image" << endl;
        imshow("Camera undistort", newimage);//显示图片
        waitKey(200);
        imwrite(imageFileName, newimage);

        imageFileName.clear();
    }
    cout << "Undistorted images are saved!" << endl;
}



int main()
{
    
    string path = "/Users/mars/Desktop/zju/stereo/Project_Stereo_left/left/*.jpg";

    vector<string>FilesName;    //存放文件名的容器

    glob(path, FilesName); // 标定所用图像文件的路径

    Size board_size = Size(9, 6);                         // 标定板上每行、列的角点数
    Size square_size = Size(30, 30);                       // 实际测量得到的标定板上每个棋盘格的物理尺寸，单位mm
    Size image_size;


    Mat cameraMatrix = Mat(3, 3, CV_32FC1, Scalar::all(0));        // 摄像机内参数矩阵
    Mat distCoeffs = Mat(1, 5, CV_32FC1, Scalar::all(0));          // 摄像机的5个畸变系数：k1,k2,p1,p2,k3(由于k3为0，k4，k5，k6不做考虑)
    vector<Mat> rvecsMat;                                          // 存放所有图像的旋转向量，每一副图像的旋转向量为一个mat
    vector<Mat> tvecsMat;                                          // 存放所有图像的平移向量，每一副图像的平移向量为一个mat

    camera_cal(FilesName, board_size, square_size, cameraMatrix, distCoeffs, rvecsMat, tvecsMat);

    img_undistort(FilesName, image_size, cameraMatrix, distCoeffs);

    return 0;
}

